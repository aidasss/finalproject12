const About = () => {
  return (
    <div className="box">
      <div className="Ocard">
        <div className="imgBx">
        <img src="https://raw.githubusercontent.com/Zhantoroev/Data-Structure/main/src/assets/N.png" alt="images" />
        </div>
        <div className="details">
          <h2>Nursultan Begaliev<br /><span>CS student</span></h2>
        </div>
      </div>
      <div className="Ocard">
        <div className="imgBx">
          <img src="https://raw.githubusercontent.com/Zhantoroev/Data-Structure/main/src/assets/S.png" alt="images" />
        </div>
        <div className="details">
          <h2>Syimyk Zhantoroev<br /><span>Cs student</span></h2>
        </div>
      </div>
    </div>

  )
}

export default About;
